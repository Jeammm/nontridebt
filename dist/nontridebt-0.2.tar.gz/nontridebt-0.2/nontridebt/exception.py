class FileNameMissingError(Exception):
    pass

class SheetNameMissingError(Exception):
    pass